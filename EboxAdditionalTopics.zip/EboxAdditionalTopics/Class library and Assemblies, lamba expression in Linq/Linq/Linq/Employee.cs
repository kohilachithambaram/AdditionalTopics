﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linq
{
    class Employee
    {
        private int _empId;
        private string _empName;
        private int _projId;

        public Employee()

        {

        }

        public Employee(int _empId, string _empName, int _projId)

        {
            this._empId = _empId;
            this._empName = _empName;
            this._projId = _projId;
        }


        public int EmpId
        {
            get

            {
                return _empId;
            }

            set

            {
                _empId = value;
            }
        }

        public string EmpName
        {
            get

            {

                return _empName;
            }

            set
            {
                _empName = value;
            }

        }

        public int ProjId
        {
            get

            {
                return _projId;
            }

            set
            {
                _projId = value;
            }

        }
    }
}
