﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linq
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> employeeList = new List<Employee>();

            Console.WriteLine("Enter the number of Employees:");
            int countEmployee = int.Parse(Console.ReadLine());
            for (int i = 0; i < countEmployee; i++)
            {

                Console.WriteLine("Enter Employee Id,Name,ProjectId " + (i + 1) + " information:");
                employeeList.Add
                  (new Employee
                  (int.Parse(Console.ReadLine()), Console.ReadLine(), int.Parse(Console.ReadLine())));
            }

            var result = (from emp in employeeList where emp.ProjId != -1
                              select new 
                              {
                                  emp.EmpId,
                                  emp.EmpName,
                                  emp.ProjId
                              }).ToList();

            Console.WriteLine("Id---Name----ProjectId");
            foreach (var data in result)
            {
                Console.WriteLine(data);
            }

        }
    }
    
}
