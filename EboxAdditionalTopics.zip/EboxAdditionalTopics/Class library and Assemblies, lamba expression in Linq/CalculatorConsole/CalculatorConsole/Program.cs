﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator;

namespace CalculatorConsole
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter operand 1");
            int op1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter operand 2");
            int op2 = int.Parse(Console.ReadLine());
            CalculatorClass cal = new CalculatorClass(op1, op2);
            Console.WriteLine("Enter your choice \n1.Addition 2.Subtraction 3.Multiplication 4.Division");
            int choice = int.Parse(Console.ReadLine());
            Console.WriteLine("Result");
            if (choice == 1)
            {
                Console.WriteLine(cal.Addition());
            }
            else if (choice == 2)
            {
                Console.WriteLine(cal.Subraction());
            }
            else if (choice == 3)
            {
                Console.WriteLine(cal.Multiplication());
            }
            if (choice == 4)
            {
                Console.WriteLine(cal.Division());
            }
        }
    }
}
