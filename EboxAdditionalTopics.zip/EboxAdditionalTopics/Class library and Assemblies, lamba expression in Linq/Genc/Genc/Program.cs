﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Genc
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Project> projectList = new List<Project>();
            List<Employee> employeeList = new List<Employee>();

            Console.WriteLine("Enter the number of projects:");
            int countProject = int.Parse(Console.ReadLine());
            for (int i = 0; i < countProject; i++)
            {
                Console.WriteLine("Enter project" + (i + 1) + " information:");
                projectList.Add
                  (new Project
                  (int.Parse(Console.ReadLine()), Console.ReadLine()));
            }


            Console.WriteLine("Enter the number of Employees:");
            int countEmployee = int.Parse(Console.ReadLine());
            for (int i = 0; i < countProject; i++)
            {
                Console.WriteLine("Enter Employee Id,Name,ProjectId " + (i + 1) + " information:");
                employeeList.Add
                  (new Employee
                  (int.Parse(Console.ReadLine()), Console.ReadLine(),
                  int.Parse(Console.ReadLine())));
            }

            var joinresult = (from emp in employeeList
                              join proj in projectList
                 on emp.ProjId equals proj.ProjId
                              select new //here we will mention the columns we
                              //want in output
                              {
                                  emp.EmpId,
                                  emp.EmpName,
                                  proj.ProjName
                              }).ToList();

            Console.WriteLine("Id---Name----Project");
            foreach (var data in joinresult)
            {
                Console.WriteLine(data);
            }
        }
    }
}
