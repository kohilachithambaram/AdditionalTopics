﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public class CalculatorClass
    {
        int operand1;
        int operand2;
        int result;

        public CalculatorClass()
        {

        }

        public CalculatorClass(int operand1, int operand2)
        {
            this.Operand1 = operand1;
            this.Operand2 = operand2;
        }
        public int Operand1
        {
            get
            {
                return operand1;
            }

            set
            {
                operand1 = value;
            }
        }

        public int Operand2
        {
            get
            {
                return operand2;
            }

            set
            {
                operand2 = value;
            }
        }

        public int Addition()
        {
            result = Operand1 + Operand2;
            return result;
        }

        public int Subraction()
        {
            result = Operand1 - Operand2;
            return result;
        }

        public int Multiplication()
        {
            result = Operand1 * Operand2;
            return result;
        }

        public int Division()
        {
            result = Operand1 / Operand2;
            return result;
        }
    }
}
