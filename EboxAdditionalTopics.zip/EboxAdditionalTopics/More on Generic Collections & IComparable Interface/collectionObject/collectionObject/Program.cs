﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace collectionObject
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> list = new List<string>();
            list.Add("101");
            list.Add("102");
            list.Add("103");
            list.Add("104");
            list.Add("105");

            Console.WriteLine("\nDisplay Data");
            foreach (string id in list)
            {
                Console.WriteLine(id);
            }
            Console.WriteLine("\nDisplay Reversed Data");
            list.Reverse();
            foreach (string id in list)
            {
                Console.WriteLine(id);
            }
            Console.WriteLine("\nDisplay index of the Data 103");
            int index = list.IndexOf("103");
            Console.WriteLine(index);
            Console.WriteLine("\nDisplay Data after removing 103");
            list.RemoveAt(index);
            foreach (string id in list)
            {
                Console.WriteLine(id);
            }
            Console.WriteLine("\nDisplay Data in array");
            int size = list.Capacity;
            string[] arr = new string[size];
            list.CopyTo(arr);
            foreach (string id in arr)
            {
                Console.WriteLine(id);
            }
        }
    }
}
