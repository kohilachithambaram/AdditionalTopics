﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionObjectsEmployee
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> empList = new List<Employee>();
            Console.WriteLine("Enter no of employees:");
            int count = int.Parse(Console.ReadLine());
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine("Enter Id andName of Employee " + (i + 1));
                empList.Add(new Employee(int.Parse(Console.ReadLine()), Console.ReadLine(), Console.ReadLine()));
            }

            Console.WriteLine("\nDisplay Data");

            foreach (Employee employee in empList)
            {
                Console.WriteLine(employee.Name);
            }
        }
    }
}
