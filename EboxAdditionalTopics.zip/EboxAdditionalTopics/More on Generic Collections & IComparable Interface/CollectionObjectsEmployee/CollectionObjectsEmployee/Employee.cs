﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionObjectsEmployee
{
    class Employee 
    {
        private int _id;
        private string _name;
        private string _designation;

        public Employee()
        {

        }

        public Employee(int _id, string _name, string _designation)
        {
            this.Id = _id;
            this.Name = _name;
            this.Designation = _designation;
        }

        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public string Designation
        {
            get
            {
                return _designation;
            }

            set
            {
                _designation = value;
            }
        }

    }
}
