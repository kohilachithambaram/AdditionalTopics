﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionObjectInsert
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> list = new List<string>();
            list.Add("101");
            list.Add("102");
            list.Add("103");
            list.Add("104");
            list.Add("105");
            list.Add("106");

            Console.WriteLine("\nDisplay Data");
            foreach (string id in list)
            {
                Console.WriteLine(id);
            }
            Console.WriteLine("\nDisplay index of the Data 106");
            int index = list.IndexOf("106");
            Console.WriteLine(index);
            Console.WriteLine("\nDisplay count of data");
            Console.WriteLine(list.Count);
        }
    }
}
