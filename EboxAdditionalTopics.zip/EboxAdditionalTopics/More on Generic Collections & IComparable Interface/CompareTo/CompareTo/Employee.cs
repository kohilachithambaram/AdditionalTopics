﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CompareTo
{
    class Employee : IComparable<Employee>
    {
        private int _id;
        private string _name;

        public Employee()
        {
                
        }

        public Employee(int _id, string _name)
        {
            this.Id = _id;
            this.Name = _name;
        }

        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public int CompareTo(Employee other)
        {
            //sort data in list of class objectys via name in desc order
            //return other.Id.CompareTo(this.Id);
            //return other.Name.CompareTo(this.Name);

            //if same name exist sort the same named data in asc order via Id
            int result = this.Name.CompareTo(other.Name);
            if (result == 0) //if same name exist
            {
                return this.Id.CompareTo(other.Id);
            }
            else
            {
                return other.Id.CompareTo(this.Id);
            }
        }

        public override string ToString()
        {
            return string.Format("{0,-20}{1}", this._id, this._name);
        }
    }
}
