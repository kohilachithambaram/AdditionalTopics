﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareTo
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> empList = new List<Employee>();
            Console.WriteLine("Enter no of employees:");
            int count = int.Parse(Console.ReadLine());
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine("Enter Id andName of Employee " + (i + 1));
                empList.Add(new Employee(int.Parse(Console.ReadLine()), Console.ReadLine()));
            }

            //use sort function
            empList.Sort(); //sort will go to CompareTo method for sorting

            Console.WriteLine("\nDisplay Data");
            Console.WriteLine("{0,-20}{1}", "Id", "Name");

            foreach (Employee employee in empList)
            {
                Console.WriteLine(employee);
            }
        }
    }
}
